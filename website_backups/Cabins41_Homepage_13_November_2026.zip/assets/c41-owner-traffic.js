(function () {
  var key = 'cabins41_ignore_own_visits';
  var url = new URL(window.location.href);
  var command = url.searchParams.get('owner-traffic');
  var excluded = false;
  try {
    if (command === 'off') localStorage.setItem(key, '1');
    if (command === 'on') localStorage.removeItem(key);
    excluded = localStorage.getItem(key) === '1';
  } catch (error) {
    if (command === 'off') {
      alert('This visit is excluded, but your browser could not save the setting. Allow site storage and open this link again.');
      return;
    }
  }
  if (command === 'off' || command === 'on') {
    url.searchParams.delete('owner-traffic');
    history.replaceState(null, '', url.pathname + url.search + url.hash);
    alert(excluded ? 'Your visits to Cabins41 are now excluded in this browser. Clearing site data or using another browser requires setting this again.' : 'Statcounter is enabled for this browser again.');
  }
  if (excluded || window.location.protocol === 'file:') return;
  window.sc_project = 13352504;
  window.sc_invisible = 1;
  window.sc_security = '246f1f17';
  var script = document.createElement('script');
  script.async = true;
  script.src = 'https://secure.statcounter.com/counter/counter.js';
  document.head.appendChild(script);
})();
